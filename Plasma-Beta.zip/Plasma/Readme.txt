Thank you for installing Plasma!
If the program doesnt open, try running it as an administrator or try opening it multiple times.